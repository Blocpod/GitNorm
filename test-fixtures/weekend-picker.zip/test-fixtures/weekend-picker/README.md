# Weekend Picker

A tiny test project used by GitNorm's end-to-end checks.
